﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContaBancáriaPOOExercício2
{
    class ContaBancaria
    {
        public string NumeroDaConta;
        public string Titular;
        public double Saldo;

        public void Depositar(double valor)
        {
            Saldo = Saldo + valor;
        }
        public void Sacar(double valor)
        {
            Saldo = Saldo - valor;
        }
        public void ExibirSaldo()
        {
            Saldo = Saldo;
        }
    }
}

