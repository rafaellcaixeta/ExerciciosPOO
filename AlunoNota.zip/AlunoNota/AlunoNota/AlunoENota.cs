﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;    
using System.Text;
using System.Threading.Tasks;

namespace AlunoNota
{
    public class AlunoENota
    {
        public int RA;
        public string Nome;
        public double NotaProva1;
        public double NotaProva2;
        public double NotaTrabalho1;
        public double NotaTrabalho2;
        public double NotaFinal;
        public void CalcularMedia()
        {
            NotaFinal = NotaProva1 + NotaProva2 + NotaTrabalho1 + NotaTrabalho2;
            NotaFinal = NotaFinal / 4;
        }
        public void CalcularNotaFinal()
        {
            if (NotaFinal >= 14)
            {
                Console.WriteLine("O aluno foi aprovado!");
            }
            else
            {
                Console.WriteLine("O aluno foi reprovado!");
            } 
        }
        public void Imprimir()
        {
            Console.WriteLine("RA: " + RA);
            Console.WriteLine("Nome: " + Nome);
            Console.WriteLine("Nota da Prova 1: " + NotaProva1);
            Console.WriteLine("Nota da Prova 2: " + NotaProva2);
            Console.WriteLine("Nota do Trabalho 1: " + NotaTrabalho1);
            Console.WriteLine("Nota do Trabalho 2: " + NotaTrabalho2);
            Console.WriteLine("Nota Final: " + NotaFinal);
        }
    }
}
