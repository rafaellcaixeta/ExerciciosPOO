﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ControleDeProdutosPOO
{
    public  class ControleDeProdutos
    {
        public string Nome;
        public double Preco;
        public int Quantidade;

        public void AdicionarEstoque(int quantidade)
        {
            Quantidade = Quantidade + quantidade;
        }
        public void RemoverEstoque(int quantidade)
        {
            Quantidade = Quantidade - quantidade;
        }
        public void ExibirDetalhes()
        {
            Quantidade = Quantidade;
        }
    }
}
