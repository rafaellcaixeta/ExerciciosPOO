﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lampada
{
    public class Lampada
    {
        public bool Ligada = false;

        public void Ligar()
        {
            Ligada = true;
        }
        public void Desligada()
        {
            Ligada = false;
        }
        public void MostrarEstado()
        {
            if (Ligada)
            {
                Console.Write("A luz está acesa.");
            }
            else
            {
                Console.Write("A luz está apagada");
            }
        }
    }
}
